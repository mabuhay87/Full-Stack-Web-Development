using Microsoft.EntityFrameworkCore;
using OpsDashboard.Web.Models;

namespace OpsDashboard.Web.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Order> Orders => Set<Order>();
    }
}