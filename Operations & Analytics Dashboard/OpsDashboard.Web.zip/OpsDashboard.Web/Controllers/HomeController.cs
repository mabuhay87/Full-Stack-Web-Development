using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OpsDashboard.Web.Data;
using OpsDashboard.Web.ViewModels;

namespace OpsDashboard.Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var now = DateTime.UtcNow;
            var sevenDaysAgo = now.AddDays(-6).Date;

            var totalOrders = await _context.Orders.CountAsync();

            // ? Use Quantity * UnitPrice instead of TotalAmount (computed property)
            var totalRevenue = await _context.Orders
                .SumAsync(o => (decimal?)(o.Quantity * o.UnitPrice)) ?? 0m;

            var last7DaysOrders = await _context.Orders
                .Where(o => o.OrderDate >= sevenDaysAgo)
                .ToListAsync();

            var ordersLast7Days = last7DaysOrders.Count;
            var revenueLast7Days = last7DaysOrders.Sum(o => o.Quantity * o.UnitPrice);

            var revenueByDay = Enumerable.Range(0, 7)
                .Select(offset =>
                {
                    var day = sevenDaysAgo.AddDays(offset).Date;
                    var dayOrders = last7DaysOrders.Where(o => o.OrderDate.Date == day);
                    return new RevenueByDay
                    {
                        DayLabel = day.ToString("MM/dd"),
                        TotalRevenue = dayOrders.Sum(o => o.Quantity * o.UnitPrice)
                    };
                })
                .ToList();

            var recentOrders = await _context.Orders
                .OrderByDescending(o => o.OrderDate)
                .Take(10)
                .ToListAsync();

            var vm = new DashboardViewModel
            {
                TotalOrders = totalOrders,
                TotalRevenue = totalRevenue,
                OrdersLast7Days = ordersLast7Days,
                RevenueLast7Days = revenueLast7Days,
                RevenueByDayLast7Days = revenueByDay,
                RecentOrders = recentOrders
            };

            return View(vm);
        }
    }
}
