using OpsDashboard.Web.Models;

namespace OpsDashboard.Web.ViewModels
{
    public class RevenueByDay
    {
        public string DayLabel { get; set; } = string.Empty;
        public decimal TotalRevenue { get; set; }
    }

    public class DashboardViewModel
    {
        public int TotalOrders { get; set; }
        public decimal TotalRevenue { get; set; }
        public int OrdersLast7Days { get; set; }
        public decimal RevenueLast7Days { get; set; }

        public List<RevenueByDay> RevenueByDayLast7Days { get; set; } = new();
        public List<Order> RecentOrders { get; set; } = new();
    }
}