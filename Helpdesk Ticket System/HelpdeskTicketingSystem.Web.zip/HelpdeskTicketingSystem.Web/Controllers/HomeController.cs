using Microsoft.AspNetCore.Mvc;

namespace HelpdeskTicketingSystem.Web.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}