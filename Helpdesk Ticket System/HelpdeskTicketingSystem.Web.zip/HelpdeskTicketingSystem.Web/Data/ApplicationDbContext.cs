using HelpdeskTicketingSystem.Web.Models;
using Microsoft.EntityFrameworkCore;

namespace HelpdeskTicketingSystem.Web.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Ticket> Tickets => Set<Ticket>();
    }
}