using System.ComponentModel.DataAnnotations;

namespace HelpdeskTicketingSystem.Web.Models
{
    public enum TicketStatus
    {
        New = 0,
        InProgress = 1,
        Resolved = 2,
        Closed = 3
    }

    public enum TicketPriority
    {
        Low = 0,
        Medium = 1,
        High = 2,
        Critical = 3
    }

    public class Ticket
    {
        public int Id { get; set; }

        [Required]
        [StringLength(200)]
        public string Title { get; set; } = string.Empty;

        [Required]
        [DataType(DataType.MultilineText)]
        public string Description { get; set; } = string.Empty;

        [Display(Name = "Requested By")]
        [Required]
        [StringLength(100)]
        public string RequestedBy { get; set; } = string.Empty;

        [Display(Name = "Assigned To")]
        [StringLength(100)]
        public string? AssignedTo { get; set; }

        [Display(Name = "Priority")]
        public TicketPriority Priority { get; set; } = TicketPriority.Medium;

        [Display(Name = "Status")]
        public TicketStatus Status { get; set; } = TicketStatus.New;

        [Display(Name = "Created At")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [Display(Name = "Updated At")]
        public DateTime? UpdatedAt { get; set; }
    }
}